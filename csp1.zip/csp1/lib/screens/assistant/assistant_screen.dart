import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:speech_to_text/speech_to_text.dart' as stt;

// ─────────────────────────────────────────────
//  Place this file at:
//  lib/screens/assistant/assistant_screen.dart
//
//  Then in home_screen.dart add a full-width card:
//
//  GestureDetector(
//    onTap: () => Navigator.push(context,
//      MaterialPageRoute(builder: (_) => const AssistantScreen())),
//    child: Container(
//      width: double.infinity,
//      margin: const EdgeInsets.symmetric(horizontal: 20),
//      padding: const EdgeInsets.all(18),
//      decoration: BoxDecoration(
//        gradient: const LinearGradient(
//          colors: [Color(0xFF1A5C2A), Color(0xFF3D9E4A)],
//        ),
//        borderRadius: BorderRadius.circular(20),
//      ),
//      child: Row(children: [
//        const Icon(Icons.mic_rounded, color: Colors.white, size: 28),
//        const SizedBox(width: 12),
//        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
//          Text('రైతు AI సహాయకుడు',
//            style: GoogleFonts.notoSansTelugu(
//              color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
//          Text('మీ ప్రశ్న అడగండి • Ask in Telugu',
//            style: GoogleFonts.dmSans(color: Colors.white70, fontSize: 12)),
//        ]),
//      ]),
//    ),
//  )
// ─────────────────────────────────────────────

// ── State machine ──────────────────────────────
enum _AssistantState { idle, listening, thinking, answered, error }

// ── Data model for one Q&A turn ────────────────
class _Turn {
  final String teluguQuestion;
  final String teluguAnswer;
  final String englishAnswer;
  final List<String> followUpChips;

  const _Turn({
    required this.teluguQuestion,
    required this.teluguAnswer,
    required this.englishAnswer,
    required this.followUpChips,
  });
}

// ══════════════════════════════════════════════
class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});

  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen>
    with TickerProviderStateMixin {
  // ── Services ──────────────────────────────────
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  // ── State ─────────────────────────────────────
  _AssistantState _state = _AssistantState.idle;
  String _liveTranscript = '';
  _Turn? _currentTurn;
  String _errorMessage = '';
  bool _isSpeaking = false;
  final List<_Turn> _history = [];

  // ── Animation controllers ─────────────────────
  late AnimationController _pulseController;
  late AnimationController _waveController;
  late AnimationController _fadeController;
  late Animation<double> _pulseAnim;
  late Animation<double> _fadeAnim;

  // ── Wave bar heights (8 bars) ─────────────────
  final List<double> _waveHeights = [8, 20, 32, 24, 36, 16, 28, 12];
  late AnimationController _waveAnimController;
  final List<AnimationController> _barControllers = [];
  final List<Animation<double>> _barAnims = [];

  // ── Context (would come from user profile / location in a real app) ──
  static const _context = {
    'location': 'Guntur, Andhra Pradesh',
    'season': 'Kharif 2025',
    'weather': '33°C, 60% rain chance',
    'commonCrops': 'Rice, Red Chilli, Cotton, Maize',
  };

  // ── Suggested starter questions ───────────────
  static const _starterQuestions = [
    'నా వరి పంటకు ఏ ఎరువు వేయాలి?',
    'ఈ వారం వర్షం వస్తుందా?',
    'మిరప ధర ఎంత ఉంది?',
    'పీఎం కిసాన్ పథకానికి ఎలా దరఖాస్తు చేయాలి?',
  ];

  // ── Starter translations ───────────────────────
  static const _starterTranslations = [
    'What fertiliser for my rice crop?',
    'Will it rain this week?',
    'What is the red chilli price?',
    'How to apply for PM-KISAN scheme?',
  ];

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _initTts();
  }

  // ────────────────────────────────────────────────
  //  Animations
  // ────────────────────────────────────────────────
  void _initAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.18).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeIn);

    // Individual bar animations — each bar gets a slightly offset controller
    final rng = Random();
    for (int i = 0; i < 8; i++) {
      final ctrl = AnimationController(
        vsync: this,
        duration: Duration(milliseconds: 500 + rng.nextInt(400)),
      )..repeat(reverse: true);
      _barControllers.add(ctrl);
      _barAnims.add(
        Tween<double>(begin: 0.25, end: 1.0).animate(
          CurvedAnimation(parent: ctrl, curve: Curves.easeInOut),
        ),
      );
    }

    // Stagger the bars
    for (int i = 0; i < _barControllers.length; i++) {
      Future.delayed(Duration(milliseconds: i * 60), () {
        if (mounted) _barControllers[i].repeat(reverse: true);
      });
    }

    _waveController = AnimationController(vsync: this);
    _waveAnimController = AnimationController(vsync: this);
  }

  // ────────────────────────────────────────────────
  //  TTS Setup
  // ────────────────────────────────────────────────
  Future<void> _initTts() async {
    await _tts.setLanguage('te-IN');
    await _tts.setSpeechRate(0.45); // Slower for clarity
    await _tts.setVolume(1.0);
    await _tts.setPitch(1.0);

    _tts.setStartHandler(() => setState(() => _isSpeaking = true));
    _tts.setCompletionHandler(() => setState(() => _isSpeaking = false));
    _tts.setCancelHandler(() => setState(() => _isSpeaking = false));
    _tts.setErrorHandler((_) => setState(() => _isSpeaking = false));
  }

  // ────────────────────────────────────────────────
  //  Speech-to-Text
  // ────────────────────────────────────────────────
  Future<void> _startListening() async {
    final available = await _speech.initialize(
      onError: (e) => _setError('Speech error: ${e.errorMsg}'),
    );
    if (!available) {
      _setError('మైక్రోఫోన్ అందుబాటులో లేదు\n(Microphone not available)');
      return;
    }

    setState(() {
      _state = _AssistantState.listening;
      _liveTranscript = '';
    });

    _speech.listen(
      localeId: 'te_IN',
      listenFor: const Duration(seconds: 15),
      pauseFor: const Duration(seconds: 3),
      onResult: (result) {
        setState(() => _liveTranscript = result.recognizedWords);
        if (result.finalResult && result.recognizedWords.isNotEmpty) {
          _stopListeningAndAsk(result.recognizedWords);
        }
      },
    );
  }

  Future<void> _stopListeningAndAsk(String transcript) async {
    await _speech.stop();
    if (transcript.trim().isEmpty) {
      setState(() => _state = _AssistantState.idle);
      return;
    }
    await _askClaude(transcript.trim());
  }

  Future<void> _stopListening() async {
    await _speech.stop();
    if (_liveTranscript.trim().isNotEmpty) {
      await _askClaude(_liveTranscript.trim());
    } else {
      setState(() => _state = _AssistantState.idle);
    }
  }

  // ────────────────────────────────────────────────
  //  Claude API Call
  // ────────────────────────────────────────────────
  Future<void> _askClaude(String teluguQuestion) async {
    setState(() => _state = _AssistantState.thinking);

    final apiKey = dotenv.env['ANTHROPIC_KEY'] ?? '';
    if (apiKey.isEmpty || apiKey == 'your_key_here') {
      _setError('API key missing. Add ANTHROPIC_KEY to your .env file.');
      return;
    }

    final systemPrompt = '''
You are Rythu AI (రైతు AI), a friendly farming assistant for small farmers in Andhra Pradesh, India.

Farmer context (use this to personalize your answer):
- Location: ${_context['location']}
- Current season: ${_context['season']}
- Today's weather: ${_context['weather']}
- Common crops in region: ${_context['commonCrops']}

Rules:
1. Answer ONLY in simple Telugu (తెలుగు). Use easy words a farmer with no education can understand.
2. Keep the Telugu answer to 2-3 short sentences maximum.
3. Be specific — mention exact quantities, timings, local market names where relevant.
4. After the Telugu answer, on a new line write "EN:" followed by a plain English translation.
5. After the English translation, on a new line write "CHIPS:" followed by 3 short Telugu follow-up questions separated by "|". Each chip must be under 5 words. These should be the most natural next questions a farmer would ask.
6. Never use technical jargon. Never use English words in the Telugu answer.

Format your response EXACTLY like this (no extra text):
[Telugu answer here]
EN:[English translation here]
CHIPS:[chip1]|[chip2]|[chip3]
''';

    try {
      final response = await http
          .post(
        Uri.parse('https://api.anthropic.com/v1/messages'),
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: jsonEncode({
          'model': 'claude-opus-4-5',
          'max_tokens': 512,
          'system': systemPrompt,
          'messages': [
            {'role': 'user', 'content': teluguQuestion},
          ],
        }),
      )
          .timeout(const Duration(seconds: 20));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final raw = (data['content'] as List)
            .whereType<Map>()
            .firstWhere((b) => b['type'] == 'text', orElse: () => {})['text'] as String? ?? '';

        final turn = _parseResponse(teluguQuestion, raw);
        setState(() {
          _currentTurn = turn;
          _state = _AssistantState.answered;
          _history.add(turn);
        });
        _fadeController.forward(from: 0);

        // Auto-speak the answer
        await _speakAnswer(turn.teluguAnswer);
      } else {
        final err = jsonDecode(response.body);
        _setError('API error ${response.statusCode}: ${err['error']?['message'] ?? 'Unknown error'}');
      }
    } catch (e) {
      _setError('నెట్‌వర్క్ లోపం\n(Network error: $e)');
    }
  }

  // ────────────────────────────────────────────────
  //  Parse Claude response into structured _Turn
  // ────────────────────────────────────────────────
  _Turn _parseResponse(String question, String raw) {
    String teluguAnswer = raw.trim();
    String englishAnswer = '';
    List<String> chips = [];

    // Extract chips
    final chipsMatch = RegExp(r'CHIPS:(.+)$', multiLine: true).firstMatch(raw);
    if (chipsMatch != null) {
      chips = chipsMatch.group(1)!
          .split('|')
          .map((c) => c.trim())
          .where((c) => c.isNotEmpty)
          .take(3)
          .toList();
      teluguAnswer = teluguAnswer
          .replaceAll(chipsMatch.group(0)!, '')
          .trim();
    }

    // Extract English translation
    final enMatch = RegExp(r'EN:(.+?)(?=CHIPS:|$)', dotAll: true).firstMatch(teluguAnswer);
    if (enMatch != null) {
      englishAnswer = enMatch.group(1)!.trim();
      teluguAnswer = teluguAnswer
          .replaceAll(enMatch.group(0)!, '')
          .trim();
    }

    // Fallback chips if not provided
    if (chips.isEmpty) {
      chips = ['మరిన్ని వివరాలు', 'ధర ఎంత?', 'ఎప్పుడు వేయాలి?'];
    }

    return _Turn(
      teluguQuestion: question,
      teluguAnswer: teluguAnswer,
      englishAnswer: englishAnswer,
      followUpChips: chips,
    );
  }

  // ────────────────────────────────────────────────
  //  TTS playback
  // ────────────────────────────────────────────────
  Future<void> _speakAnswer(String text) async {
    if (_isSpeaking) {
      await _tts.stop();
      setState(() => _isSpeaking = false);
      return;
    }
    setState(() => _isSpeaking = true);
    await _tts.speak(text);
  }

  // ────────────────────────────────────────────────
  //  Ask a starter / chip question directly
  // ────────────────────────────────────────────────
  Future<void> _askText(String question) async {
    setState(() {
      _liveTranscript = question;
    });
    await _askClaude(question);
  }

  void _setError(String msg) {
    setState(() {
      _state = _AssistantState.error;
      _errorMessage = msg;
    });
  }

  void _reset() {
    setState(() {
      _state = _AssistantState.idle;
      _liveTranscript = '';
      _errorMessage = '';
    });
    _fadeController.reset();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _fadeController.dispose();
    _waveController.dispose();
    _waveAnimController.dispose();
    for (final c in _barControllers) {
      c.dispose();
    }
    _speech.stop();
    _tts.stop();
    super.dispose();
  }

  // ════════════════════════════════════════════════
  //  BUILD
  // ════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F2EB),
      body: Column(
        children: [
          _buildHeader(),
          _buildContextBanner(),
          Expanded(child: _buildBody()),
          _buildBottomBar(),
        ],
      ),
    );
  }

  // ────────────────────────────────────────────────
  //  Header
  // ────────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.fromLTRB(
          16, MediaQuery.of(context).padding.top + 12, 16, 16),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF1A5C2A), Color(0xFF3D9E4A)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'రైతు AI సహాయకుడు',
                  style: GoogleFonts.notoSansTelugu(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Farmer AI Assistant · తెలుగు',
                  style: GoogleFonts.dmSans(
                      color: Colors.white60, fontSize: 11),
                ),
              ],
            ),
          ),
          // Language badge
          Container(
            padding:
            const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              'తెలుగు / EN',
              style: GoogleFonts.dmSans(
                  color: Colors.white, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  // ────────────────────────────────────────────────
  //  Context banner (auto-detected farmer context)
  // ────────────────────────────────────────────────
  Widget _buildContextBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF8EE),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE8E3D9)),
      ),
      child: Row(
        children: [
          const Icon(Icons.location_on_rounded,
              size: 14, color: Color(0xFF854F0B)),
          const SizedBox(width: 6),
          Text(
            'Guntur, AP  ·  Kharif 2025  ·  33°C, 60% rain',
            style: GoogleFonts.dmSans(
                fontSize: 11, color: const Color(0xFF633806)),
          ),
          const Spacer(),
          Text(
            'Auto context',
            style: GoogleFonts.dmSans(
              fontSize: 9,
              color: const Color(0xFF854F0B),
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ────────────────────────────────────────────────
  //  Main body — switches by state
  // ────────────────────────────────────────────────
  Widget _buildBody() {
    switch (_state) {
      case _AssistantState.idle:
        return _buildIdleState();
      case _AssistantState.listening:
        return _buildListeningState();
      case _AssistantState.thinking:
        return _buildThinkingState();
      case _AssistantState.answered:
        return _buildAnsweredState();
      case _AssistantState.error:
        return _buildErrorState();
    }
  }

  // ── IDLE ──────────────────────────────────────
  Widget _buildIdleState() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const SizedBox(height: 16),
          // Pulsing mic
          ScaleTransition(
            scale: _pulseAnim,
            child: Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                color: const Color(0xFF1A5C2A),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF1A5C2A).withOpacity(0.25),
                    blurRadius: 24,
                    spreadRadius: 8,
                  ),
                ],
              ),
              child: const Icon(Icons.mic_rounded,
                  color: Colors.white, size: 38),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'మీ ప్రశ్న అడగండి',
            style: GoogleFonts.notoSansTelugu(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: const Color(0xFF1A3A1F),
            ),
          ),
          Text(
            'Tap the mic below and speak in Telugu',
            style: GoogleFonts.dmSans(
                fontSize: 12, color: const Color(0xFF8A9C7E)),
          ),
          const SizedBox(height: 28),

          // Starter question chips
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'సూచించిన ప్రశ్నలు',
              style: GoogleFonts.dmSans(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.7,
                color: const Color(0xFF3A4A35),
              ),
            ),
          ),
          const SizedBox(height: 10),
          ...List.generate(_starterQuestions.length, (i) {
            return GestureDetector(
              onTap: () => _askText(_starterQuestions[i]),
              child: Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFFE8E3D9)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.record_voice_over_rounded,
                        size: 16, color: Color(0xFF1A5C2A)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _starterQuestions[i],
                            style: GoogleFonts.notoSansTelugu(
                              fontSize: 13,
                              color: const Color(0xFF1A3A1F),
                            ),
                          ),
                          Text(
                            _starterTranslations[i],
                            style: GoogleFonts.dmSans(
                              fontSize: 10,
                              color: const Color(0xFF8A9C7E),
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios_rounded,
                        size: 12, color: Color(0xFF8A9C7E)),
                  ],
                ),
              ),
            );
          }),

          // History
          if (_history.isNotEmpty) ...[
            const SizedBox(height: 20),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'ముందు అడిగిన ప్రశ్నలు',
                style: GoogleFonts.dmSans(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.7,
                  color: const Color(0xFF3A4A35),
                ),
              ),
            ),
            const SizedBox(height: 8),
            ...(_history.reversed.take(3).map((t) => GestureDetector(
              onTap: () => _askText(t.teluguQuestion),
              child: Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFF5F2EB),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFE8E3D9)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.history_rounded,
                        size: 13, color: Color(0xFF8A9C7E)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        t.teluguQuestion,
                        style: GoogleFonts.notoSansTelugu(
                          fontSize: 12,
                          color: const Color(0xFF6B7C5E),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ))),
          ],
        ],
      ),
    );
  }

  // ── LISTENING ─────────────────────────────────
  Widget _buildListeningState() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Animated wave bars
          SizedBox(
            height: 80,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: List.generate(8, (i) {
                return AnimatedBuilder(
                  animation: _barControllers[i],
                  builder: (_, __) {
                    final h = _waveHeights[i] * _barAnims[i].value +
                        _waveHeights[i] * 0.25;
                    return Container(
                      width: 5,
                      height: h,
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1A5C2A),
                        borderRadius: BorderRadius.circular(3),
                      ),
                    );
                  },
                );
              }),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'వింటున్నాను...',
            style: GoogleFonts.notoSansTelugu(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: const Color(0xFF1A3A1F),
            ),
          ),
          Text(
            'Listening... speak clearly',
            style: GoogleFonts.dmSans(
                fontSize: 12, color: const Color(0xFF8A9C7E)),
          ),
          const SizedBox(height: 20),

          // Live transcript box
          if (_liveTranscript.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE8E3D9)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'వింటున్నది',
                    style: GoogleFonts.dmSans(
                      fontSize: 9,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.6,
                      color: const Color(0xFF8A9C7E),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    _liveTranscript,
                    style: GoogleFonts.notoSansTelugu(
                      fontSize: 15,
                      color: const Color(0xFF1A3A1F),
                    ),
                  ),
                ],
              ),
            ),

          const SizedBox(height: 20),
          // Stop & ask button
          GestureDetector(
            onTap: _stopListening,
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 28, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF1A5C2A),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Text(
                'పూర్తయింది • Done',
                style: GoogleFonts.dmSans(
                    color: Colors.white, fontSize: 13),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── THINKING ──────────────────────────────────
  Widget _buildThinkingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(
            width: 48,
            height: 48,
            child: CircularProgressIndicator(
              color: Color(0xFF1A5C2A),
              strokeWidth: 3,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'ఆలోచిస్తున్నాను...',
            style: GoogleFonts.notoSansTelugu(
              fontSize: 16,
              color: const Color(0xFF1A3A1F),
            ),
          ),
          Text(
            'AI is thinking...',
            style: GoogleFonts.dmSans(
                fontSize: 12, color: const Color(0xFF8A9C7E)),
          ),
          if (_liveTranscript.isNotEmpty) ...[
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFE8E3D9)),
                ),
                child: Text(
                  '"$_liveTranscript"',
                  style: GoogleFonts.notoSansTelugu(
                    fontSize: 13,
                    color: const Color(0xFF6B7C5E),
                    fontStyle: FontStyle.italic,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ── ANSWERED ──────────────────────────────────
  Widget _buildAnsweredState() {
    if (_currentTurn == null) return _buildIdleState();
    final turn = _currentTurn!;

    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // You asked
            _sectionLabel('మీరు అడిగారు'),
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE8E3D9)),
              ),
              child: Text(
                turn.teluguQuestion,
                style: GoogleFonts.notoSansTelugu(
                    fontSize: 14, color: const Color(0xFF1A3A1F)),
              ),
            ),
            const SizedBox(height: 16),

            // AI response card
            _sectionLabel('రైతు AI సమాధానం'),
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE8E3D9)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // AI name row
                  Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: Color(0xFF1A5C2A),
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'RYTHU AI',
                        style: GoogleFonts.dmSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: const Color(0xFF1A5C2A),
                          letterSpacing: 0.5,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        'Guntur context used',
                        style: GoogleFonts.dmSans(
                            fontSize: 9, color: const Color(0xFF8A9C7E)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Telugu answer (large, prominent)
                  Text(
                    turn.teluguAnswer,
                    style: GoogleFonts.notoSansTelugu(
                      fontSize: 16,
                      color: const Color(0xFF1A3A1F),
                      height: 1.65,
                    ),
                  ),

                  // English translation (muted, smaller)
                  if (turn.englishAnswer.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF5F2EB),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        turn.englishAnswer,
                        style: GoogleFonts.dmSans(
                          fontSize: 12,
                          color: const Color(0xFF6B7C5E),
                          fontStyle: FontStyle.italic,
                          height: 1.5,
                        ),
                      ),
                    ),
                  ],

                  const SizedBox(height: 14),

                  // Speak / stop button
                  GestureDetector(
                    onTap: () => _speakAnswer(turn.teluguAnswer),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 9),
                      decoration: BoxDecoration(
                        color: _isSpeaking
                            ? const Color(0xFFFCEBEB)
                            : const Color(0xFFEAF3DE),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _isSpeaking
                                ? Icons.stop_circle_rounded
                                : Icons.volume_up_rounded,
                            size: 16,
                            color: _isSpeaking
                                ? const Color(0xFFA32D2D)
                                : const Color(0xFF27500A),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            _isSpeaking
                                ? 'ఆపు • Stop'
                                : 'సమాధానం వినండి • Hear answer',
                            style: GoogleFonts.dmSans(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: _isSpeaking
                                  ? const Color(0xFFA32D2D)
                                  : const Color(0xFF27500A),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Follow-up chips
            _sectionLabel('తదుపరి ప్రశ్నలు'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: turn.followUpChips.map((chip) {
                return GestureDetector(
                  onTap: () => _askText(chip),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFE8E3D9)),
                    ),
                    child: Text(
                      chip,
                      style: GoogleFonts.notoSansTelugu(
                          fontSize: 12, color: const Color(0xFF1A3A1F)),
                    ),
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: 20),
            // Ask another
            GestureDetector(
              onTap: _reset,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 13),
                decoration: BoxDecoration(
                  color: const Color(0xFFF5F2EB),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFFE8E3D9)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.mic_none_rounded,
                        size: 16, color: Color(0xFF1A5C2A)),
                    const SizedBox(width: 8),
                    Text(
                      'మరొక ప్రశ్న అడగండి • Ask another',
                      style: GoogleFonts.dmSans(
                        fontSize: 13,
                        color: const Color(0xFF1A5C2A),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── ERROR ─────────────────────────────────────
  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: const Color(0xFFFCEBEB),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.error_outline_rounded,
                  color: Color(0xFFA32D2D), size: 32),
            ),
            const SizedBox(height: 16),
            Text(
              'లోపం జరిగింది',
              style: GoogleFonts.notoSansTelugu(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: const Color(0xFF1A3A1F),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _errorMessage,
              style: GoogleFonts.dmSans(
                fontSize: 12,
                color: const Color(0xFF8A9C7E),
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            GestureDetector(
              onTap: _reset,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 28, vertical: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A5C2A),
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Text(
                  'మళ్ళీ ప్రయత్నించు • Try again',
                  style: GoogleFonts.dmSans(
                      color: Colors.white, fontSize: 13),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ────────────────────────────────────────────────
  //  Bottom mic bar
  // ────────────────────────────────────────────────
  Widget _buildBottomBar() {
    final isListening = _state == _AssistantState.listening;
    final isThinking = _state == _AssistantState.thinking;

    return Container(
      padding: EdgeInsets.fromLTRB(
          20, 12, 20, MediaQuery.of(context).padding.bottom + 12),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFE8E3D9))),
      ),
      child: Row(
        children: [
          // Main mic button
          GestureDetector(
            onTap: isThinking
                ? null
                : isListening
                ? _stopListening
                : _startListening,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: isListening
                    ? const Color(0xFFA32D2D)
                    : isThinking
                    ? const Color(0xFF8A9C7E)
                    : const Color(0xFF1A5C2A),
                shape: BoxShape.circle,
              ),
              child: Icon(
                isListening
                    ? Icons.stop_rounded
                    : Icons.mic_rounded,
                color: Colors.white,
                size: 26,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  isListening
                      ? 'వింటున్నాను...'
                      : isThinking
                      ? 'ఆలోచిస్తున్నాను...'
                      : 'మాట్లాడండి',
                  style: GoogleFonts.notoSansTelugu(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF1A3A1F),
                  ),
                ),
                Text(
                  isListening
                      ? 'Tap stop when done speaking'
                      : isThinking
                      ? 'Getting your answer...'
                      : 'Tap mic and ask in Telugu',
                  style: GoogleFonts.dmSans(
                      fontSize: 11, color: const Color(0xFF8A9C7E)),
                ),
              ],
            ),
          ),
          // TTS indicator
          if (_isSpeaking)
            Container(
              padding:
              const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFEAF3DE),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.volume_up_rounded,
                      size: 12, color: Color(0xFF1A5C2A)),
                  const SizedBox(width: 4),
                  Text(
                    'Speaking',
                    style: GoogleFonts.dmSans(
                      fontSize: 10,
                      color: const Color(0xFF27500A),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // ────────────────────────────────────────────────
  //  Helper
  // ────────────────────────────────────────────────
  Widget _sectionLabel(String label) {
    return Text(
      label.toUpperCase(),
      style: GoogleFonts.dmSans(
        fontSize: 10,
        fontWeight: FontWeight.w600,
        color: const Color(0xFF3A4A35),
        letterSpacing: 0.7,
      ),
    );
  }
}