import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SchemesScreen extends StatefulWidget {
  const SchemesScreen({super.key});

  @override
  State<SchemesScreen> createState() => _SchemesScreenState();
}

class _SchemesScreenState extends State<SchemesScreen> {
  int _selectedTab = 0;
  final List<String> _tabs = ['All', 'Central', 'State', 'Loans'];

  final List<_Scheme> _schemes = [
    _Scheme(
      name: 'PM-KISAN',
      description: '₹6,000/year income support to eligible farmer families',
      icon: Icons.currency_rupee_rounded,
      iconBg: const Color(0xFFE6F5EC),
      iconColor: const Color(0xFF1A5C2A),
      tag: 'Central',
      tagBg: const Color(0xFFEAF3DE),
      tagColor: const Color(0xFF27500A),
      deadline: 'Open',
      deadlineBg: const Color(0xFFEAF3DE),
      deadlineColor: const Color(0xFF3B6D11),
    ),
    _Scheme(
      name: 'Rythu Bandhu',
      description: '₹10,000/acre per season investment support for farmers',
      icon: Icons.agriculture_rounded,
      iconBg: const Color(0xFFFAEEDA),
      iconColor: const Color(0xFF854F0B),
      tag: 'State (AP)',
      tagBg: const Color(0xFFFAEEDA),
      tagColor: const Color(0xFF633806),
      deadline: 'Open',
      deadlineBg: const Color(0xFFEAF3DE),
      deadlineColor: const Color(0xFF3B6D11),
    ),
    _Scheme(
      name: 'PMFBY',
      description: 'Crop insurance scheme against natural calamities',
      icon: Icons.shield_rounded,
      iconBg: const Color(0xFFE6F1FB),
      iconColor: const Color(0xFF185FA5),
      tag: 'Central',
      tagBg: const Color(0xFFE6F1FB),
      tagColor: const Color(0xFF0C447C),
      deadline: 'Mar 31',
      deadlineBg: const Color(0xFFFCEBEB),
      deadlineColor: const Color(0xFFA32D2D),
    ),
    _Scheme(
      name: 'KCC Loan',
      description: 'Short-term credit at 4% interest for crop production',
      icon: Icons.credit_card_rounded,
      iconBg: const Color(0xFFF4E6F5),
      iconColor: const Color(0xFF7B3FA0),
      tag: 'Loans',
      tagBg: const Color(0xFFF4E6F5),
      tagColor: const Color(0xFF5A2D80),
      deadline: 'Open',
      deadlineBg: const Color(0xFFEAF3DE),
      deadlineColor: const Color(0xFF3B6D11),
    ),
    _Scheme(
      name: 'Soil Health Card',
      description: 'Free soil testing and nutrient recommendations',
      icon: Icons.grass_rounded,
      iconBg: const Color(0xFFE6F5EC),
      iconColor: const Color(0xFF1A5C2A),
      tag: 'Central',
      tagBg: const Color(0xFFEAF3DE),
      tagColor: const Color(0xFF27500A),
      deadline: 'Open',
      deadlineBg: const Color(0xFFEAF3DE),
      deadlineColor: const Color(0xFF3B6D11),
    ),
    _Scheme(
      name: 'AP Micro Irrigation',
      description: 'Subsidy up to 90% for drip and sprinkler irrigation',
      icon: Icons.water_drop_rounded,
      iconBg: const Color(0xFFE6F1FB),
      iconColor: const Color(0xFF185FA5),
      tag: 'State (AP)',
      tagBg: const Color(0xFFFAEEDA),
      tagColor: const Color(0xFF633806),
      deadline: 'Apr 15',
      deadlineBg: const Color(0xFFFFF4E6),
      deadlineColor: const Color(0xFF854F0B),
    ),
  ];

  List<_Scheme> get _filtered {
    if (_selectedTab == 0) return _schemes;
    return _schemes
        .where((s) => s.tag.contains(_tabs[_selectedTab]))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F2EB),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            _buildInfoBanner(),
            const SizedBox(height: 12),
            _buildTabs(),
            const SizedBox(height: 8),
            Expanded(child: _buildSchemeList()),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Text(
        'Government Schemes',
        style: GoogleFonts.dmSans(
          fontSize: 22,
          fontWeight: FontWeight.w600,
          color: const Color(0xFF1A3A1F),
        ),
      ),
    );
  }

  Widget _buildInfoBanner() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF1A5C2A), Color(0xFF3D9E4A)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            const Icon(Icons.info_outline_rounded,
                color: Colors.white70, size: 22),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                '6 active schemes available for Guntur farmers',
                style: GoogleFonts.dmSans(
                    fontSize: 13, color: Colors.white, height: 1.4),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabs() {
    return SizedBox(
      height: 36,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _tabs.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final selected = _selectedTab == i;
          return GestureDetector(
            onTap: () => setState(() => _selectedTab = i),
            child: Container(
              padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: selected ? const Color(0xFF1A5C2A) : Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: selected
                      ? const Color(0xFF1A5C2A)
                      : const Color(0xFFE8E3D9),
                ),
              ),
              child: Text(
                _tabs[i],
                style: GoogleFonts.dmSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color:
                  selected ? Colors.white : const Color(0xFF6B7C5E),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSchemeList() {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
      itemCount: _filtered.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) => _schemeCard(_filtered[i]),
    );
  }

  Widget _schemeCard(_Scheme s) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE8E3D9)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: s.iconBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(s.icon, color: s.iconColor, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      s.name,
                      style: GoogleFonts.dmSans(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF1A3A1F),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        _pill(s.tag, s.tagBg, s.tagColor),
                        const SizedBox(width: 6),
                        _pill(
                          s.deadline == 'Open'
                              ? '✓ Open'
                              : '⏰ ${s.deadline}',
                          s.deadlineBg,
                          s.deadlineColor,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            s.description,
            style: GoogleFonts.dmSans(
              fontSize: 13,
              color: const Color(0xFF6B7C5E),
              height: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: TextButton(
              onPressed: () {},
              style: TextButton.styleFrom(
                backgroundColor: const Color(0xFFE6F5EC),
                foregroundColor: const Color(0xFF1A5C2A),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: const EdgeInsets.symmetric(vertical: 10),
              ),
              child: Text(
                'Check Eligibility & Apply',
                style: GoogleFonts.dmSans(
                    fontSize: 13, fontWeight: FontWeight.w500),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _pill(String text, Color bg, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: GoogleFonts.dmSans(
            fontSize: 10, fontWeight: FontWeight.w500, color: color),
      ),
    );
  }
}

class _Scheme {
  final String name;
  final String description;
  final IconData icon;
  final Color iconBg;
  final Color iconColor;
  final String tag;
  final Color tagBg;
  final Color tagColor;
  final String deadline;
  final Color deadlineBg;
  final Color deadlineColor;

  const _Scheme({
    required this.name,
    required this.description,
    required this.icon,
    required this.iconBg,
    required this.iconColor,
    required this.tag,
    required this.tagBg,
    required this.tagColor,
    required this.deadline,
    required this.deadlineBg,
    required this.deadlineColor,
  });
}
