import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class WeatherScreen extends StatelessWidget {
  const WeatherScreen({super.key});

  // 👇 ADD HERE (inside class, before build method)
  Future<Map<String, dynamic>> fetchWeather() async {
  final response = await http.get(
  Uri.parse(
  'https://api.openweathermap.org/data/2.5/weather?q=Guntur&appid=89fceda9228bd40e191a17a9ddcb604e&units=metric',
  ),
  );

  if (response.statusCode == 200) {
  return json.decode(response.body);
  } else {
  throw Exception('Failed to load weather');
  }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F2EB),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(context),
              _buildCurrentWeatherCard(),
              const SizedBox(height: 16),
              _buildSectionTitle('7-Day Forecast'),
              const SizedBox(height: 8),
              _buildForecastList(),
              const SizedBox(height: 16),
              _buildSectionTitle('Today\'s Hourly'),
              const SizedBox(height: 8),
              _buildHourlyScroll(),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Row(
        children: [
          Text(
            'Weather',
            style: GoogleFonts.dmSans(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF1A3A1F),
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: const Color(0xFFE6F5EC),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                const Icon(Icons.location_on_rounded,
                    size: 13, color: Color(0xFF1A5C2A)),
                const SizedBox(width: 3),
                Text(
                  'Guntur, AP',
                  style: GoogleFonts.dmSans(
                    fontSize: 12,
                    color: const Color(0xFF1A5C2A),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentWeatherCard() {
    return FutureBuilder(
      future: fetchWeather(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return const Center(child: Text("Error loading weather"));
        }

        final data = snapshot.data as Map<String, dynamic>;

        final temp = data['main']['temp'];
        final condition = data['weather'][0]['main'];
        final humidity = data['main']['humidity'];

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1A5C2A), Color(0xFF3D9E4A)],
              ),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              children: [
                const Icon(Icons.cloud_rounded, color: Colors.white70, size: 56),
                const SizedBox(height: 8),
                Text(
                  "$temp°C",
                  style: const TextStyle(
                      fontSize: 40,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                ),
                Text(condition, style: const TextStyle(color: Colors.white)),
                const SizedBox(height: 10),
                Text(
                  "Humidity: $humidity%",
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _statChip(IconData icon, String value, String label) {
    return Column(
      children: [
        Icon(icon, color: Colors.white70, size: 18),
        const SizedBox(height: 4),
        Text(value,
            style: GoogleFonts.dmSans(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Colors.white)),
        Text(label,
            style:
            GoogleFonts.dmSans(fontSize: 11, color: Colors.white60)),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Text(
        title.toUpperCase(),
        style: GoogleFonts.dmSans(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: const Color(0xFF3A4A35),
          letterSpacing: 0.8,
        ),
      ),
    );
  }

  Widget _buildForecastList() {
    final forecasts = [
      _Forecast('Today', Icons.cloud_rounded, 33, 24, 60),
      _Forecast('Tue', Icons.thunderstorm_rounded, 29, 22, 85),
      _Forecast('Wed', Icons.grain_rounded, 27, 21, 75),
      _Forecast('Thu', Icons.wb_sunny_rounded, 34, 23, 20),
      _Forecast('Fri', Icons.wb_cloudy_rounded, 32, 22, 35),
      _Forecast('Sat', Icons.wb_sunny_rounded, 35, 24, 10),
      _Forecast('Sun', Icons.cloud_rounded, 31, 22, 45),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFE8E3D9)),
        ),
        child: Column(
          children: forecasts.asMap().entries.map((e) {
            final isLast = e.key == forecasts.length - 1;
            return _forecastRow(e.value, isLast);
          }).toList(),
        ),
      ),
    );
  }

  Widget _forecastRow(_Forecast f, bool isLast) {
    Color iconColor;
    if (f.icon == Icons.thunderstorm_rounded || f.icon == Icons.grain_rounded) {
      iconColor = const Color(0xFF378ADD);
    } else if (f.icon == Icons.wb_sunny_rounded) {
      iconColor = const Color(0xFFBA7517);
    } else {
      iconColor = const Color(0xFF6B7C5E);
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: isLast
            ? null
            : const Border(
            bottom: BorderSide(color: Color(0xFFE8E3D9), width: 0.5)),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 44,
            child: Text(
              f.day,
              style: GoogleFonts.dmSans(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: const Color(0xFF2A3A25),
              ),
            ),
          ),
          Icon(f.icon, color: iconColor, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE6F1FB),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    '${f.rainChance}% rain',
                    style: GoogleFonts.dmSans(
                      fontSize: 11,
                      color: const Color(0xFF0C447C),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Text(
            '${f.low}°',
            style: GoogleFonts.dmSans(
                fontSize: 13, color: const Color(0xFF8A9C7E)),
          ),
          const SizedBox(width: 8),
          Text(
            '${f.high}°',
            style: GoogleFonts.dmSans(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF1A3A1F)),
          ),
        ],
      ),
    );
  }

  Widget _buildHourlyScroll() {
    final hours = [
      _Hourly('6 AM', Icons.wb_sunny_rounded, 27),
      _Hourly('9 AM', Icons.wb_cloudy_rounded, 29),
      _Hourly('12 PM', Icons.cloud_rounded, 31),
      _Hourly('3 PM', Icons.thunderstorm_rounded, 30),
      _Hourly('6 PM', Icons.grain_rounded, 28),
      _Hourly('9 PM', Icons.cloud_rounded, 26),
    ];

    return SizedBox(
      height: 100,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: hours.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (_, i) => _hourlyCard(hours[i]),
      ),
    );
  }

  Widget _hourlyCard(_Hourly h) {
    return Container(
      width: 72,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE8E3D9)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text(h.time,
              style: GoogleFonts.dmSans(
                  fontSize: 11, color: const Color(0xFF8A9C7E))),
          Icon(h.icon, size: 22, color: const Color(0xFF3A4A35)),
          Text('${h.temp}°',
              style: GoogleFonts.dmSans(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: const Color(0xFF1A3A1F))),
        ],
      ),
    );
  }
}

class _Forecast {
  final String day;
  final IconData icon;
  final int high;
  final int low;
  final int rainChance;
  const _Forecast(this.day, this.icon, this.high, this.low, this.rainChance);
}

class _Hourly {
  final String time;
  final IconData icon;
  final int temp;
  const _Hourly(this.time, this.icon, this.temp);
}
