import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MarketScreen extends StatefulWidget {
  const MarketScreen({super.key});

  @override
  State<MarketScreen> createState() => _MarketScreenState();
}

class _MarketScreenState extends State<MarketScreen> {
  int _selectedTab = 0;
  final List<String> _tabs = ['All', 'Grains', 'Vegetables', 'Fruits'];

  final List<_CropPrice> _allCrops = [
    _CropPrice('Rice', 'Guntur APMC', 2350, 2280, '🌾', 'Grains'),
    _CropPrice('Maize', 'Tenali Market', 1820, 1900, '🌽', 'Grains'),
    _CropPrice('Red Chilli', 'Guntur APMC', 15200, 14800, '🌶', 'Vegetables'),
    _CropPrice('Tomato', 'Vijayawada', 1200, 900, '🍅', 'Vegetables'),
    _CropPrice('Onion', 'Tenali Market', 1450, 1600, '🧅', 'Vegetables'),
    _CropPrice('Cotton', 'Guntur APMC', 6800, 6950, '🌿', 'Grains'),
    _CropPrice('Banana', 'Eluru Market', 2200, 2100, '🍌', 'Fruits'),
    _CropPrice('Mango', 'Vijayawada', 4500, 4200, '🥭', 'Fruits'),
  ];

  List<_CropPrice> get _filteredCrops {
    if (_selectedTab == 0) return _allCrops;
    return _allCrops
        .where((c) => c.category == _tabs[_selectedTab])
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F2EB),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            _buildSummaryRow(),
            const SizedBox(height: 12),
            _buildTabs(),
            const SizedBox(height: 8),
            Expanded(child: _buildCropList()),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Row(
        children: [
          Text(
            'Market Prices',
            style: GoogleFonts.dmSans(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF1A3A1F),
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: const Color(0xFFE6F5EC),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              'Mon, 23 Mar',
              style: GoogleFonts.dmSans(
                  fontSize: 12,
                  color: const Color(0xFF1A5C2A),
                  fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _summaryCard('↑ Risers', '3', const Color(0xFFE6F5EC),
              const Color(0xFF1A5C2A)),
          const SizedBox(width: 10),
          _summaryCard('↓ Fallers', '4', const Color(0xFFFCEBEB),
              const Color(0xFFA32D2D)),
          const SizedBox(width: 10),
          _summaryCard('Markets', '4', const Color(0xFFFAEEDA),
              const Color(0xFF633806)),
        ],
      ),
    );
  }

  Widget _summaryCard(
      String label, String value, Color bg, Color textColor) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(value,
                style: GoogleFonts.dmSans(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                    color: textColor)),
            Text(label,
                style: GoogleFonts.dmSans(
                    fontSize: 11, color: textColor.withOpacity(0.75))),
          ],
        ),
      ),
    );
  }

  Widget _buildTabs() {
    return SizedBox(
      height: 36,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _tabs.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final selected = _selectedTab == i;
          return GestureDetector(
            onTap: () => setState(() => _selectedTab = i),
            child: Container(
              padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: selected
                    ? const Color(0xFF1A5C2A)
                    : Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: selected
                      ? const Color(0xFF1A5C2A)
                      : const Color(0xFFE8E3D9),
                ),
              ),
              child: Text(
                _tabs[i],
                style: GoogleFonts.dmSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: selected ? Colors.white : const Color(0xFF6B7C5E),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCropList() {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
      itemCount: _filteredCrops.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, i) => _cropCard(_filteredCrops[i]),
    );
  }

  Widget _cropCard(_CropPrice crop) {
    final isUp = crop.currentPrice >= crop.previousPrice;
    final diff = crop.currentPrice - crop.previousPrice;
    final diffAbs = diff.abs();
    final pct = (diffAbs / crop.previousPrice * 100).toStringAsFixed(1);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE8E3D9)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: const Color(0xFFF5F2EB),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(crop.emoji,
                  style: const TextStyle(fontSize: 22)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  crop.name,
                  style: GoogleFonts.dmSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: const Color(0xFF1A3A1F),
                  ),
                ),
                Text(
                  crop.market,
                  style: GoogleFonts.dmSans(
                    fontSize: 11,
                    color: const Color(0xFF8A9C7E),
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '₹${crop.currentPrice}/q',
                style: GoogleFonts.dmSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFF1A3A1F),
                ),
              ),
              Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(
                  color: isUp
                      ? const Color(0xFFEAF3DE)
                      : const Color(0xFFFCEBEB),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      isUp
                          ? Icons.arrow_upward_rounded
                          : Icons.arrow_downward_rounded,
                      size: 10,
                      color: isUp
                          ? const Color(0xFF3B6D11)
                          : const Color(0xFFA32D2D),
                    ),
                    const SizedBox(width: 2),
                    Text(
                      '$pct%',
                      style: GoogleFonts.dmSans(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: isUp
                            ? const Color(0xFF3B6D11)
                            : const Color(0xFFA32D2D),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CropPrice {
  final String name;
  final String market;
  final int currentPrice;
  final int previousPrice;
  final String emoji;
  final String category;

  const _CropPrice(this.name, this.market, this.currentPrice,
      this.previousPrice, this.emoji, this.category);
}