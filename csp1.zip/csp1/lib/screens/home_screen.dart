import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'weather/weather_screen.dart';
import 'market/market_screen.dart';
import 'schemes/schemes_screen.dart';
import 'diary/diary_screen.dart';
import 'assistant/assistant_screen.dart'; // ← NEW

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F2EB),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildAiCard(context),   // ← NEW hero card
            const SizedBox(height: 20),
            _buildSectionLabel('Quick Access'),
            const SizedBox(height: 10),
            _buildGrid(context),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  // ── Header ──────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 54, 20, 28),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF1A5C2A), Color(0xFF3D9E4A)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'నమస్కారం రైతు 👋',
            style: GoogleFonts.notoSansTelugu(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Smart Farming Assistant · Guntur, AP',
            style: GoogleFonts.dmSans(
              color: Colors.white70,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 20),

          // Quick stat pills row
          Row(
            children: [
              _statPill('33°C', "Today's high"),
              const SizedBox(width: 8),
              _statPill('₹2,350', 'Rice / qtl'),
              const SizedBox(width: 8),
              _statPill('6', 'Schemes open'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statPill(String value, String label) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.15),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              value,
              style: GoogleFonts.dmSans(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            Text(
              label,
              style: GoogleFonts.dmSans(
                color: Colors.white60,
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── AI Assistant Hero Card ───────────────────────
  Widget _buildAiCard(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const AssistantScreen()),
      ),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF1A5C2A), Color(0xFF3D9E4A)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Row(
          children: [
            // Mic icon in circle
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.mic_rounded,
                color: Colors.white,
                size: 26,
              ),
            ),
            const SizedBox(width: 16),

            // Text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'రైతు AI సహాయకుడు',
                    style: GoogleFonts.notoSansTelugu(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    'మీ ప్రశ్న అడగండి • Ask in Telugu',
                    style: GoogleFonts.dmSans(
                      color: Colors.white70,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      'AI-Powered · తెలుగు Voice',
                      style: GoogleFonts.dmSans(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Arrow
            const Icon(
              Icons.arrow_forward_ios_rounded,
              color: Colors.white54,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  // ── Section label ────────────────────────────────
  Widget _buildSectionLabel(String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          label.toUpperCase(),
          style: GoogleFonts.dmSans(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF3A4A35),
            letterSpacing: 0.8,
          ),
        ),
      ),
    );
  }

  // ── 2×2 Grid ────────────────────────────────────
  Widget _buildGrid(BuildContext context) {
    final items = [
      _GridItem('Weather', Icons.cloud_rounded, '60% rain tomorrow',
          const Color(0xFFE6F5EC), WeatherScreen()),
      _GridItem('Market', Icons.bar_chart_rounded, '3 prices up today',
          const Color(0xFFFFF4E6), MarketScreen()),
      _GridItem('Schemes', Icons.account_balance_rounded, 'PMFBY due Mar 31',
          const Color(0xFFEAF3DE), SchemesScreen()),
      _GridItem('Farm Diary', Icons.menu_book_rounded, 'Add today\'s entry',
          const Color(0xFFF4E6F5), DiaryScreen()),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.1,
        children: items.map((item) => _buildGridCard(context, item)).toList(),
      ),
    );
  }

  Widget _buildGridCard(BuildContext context, _GridItem item) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => item.screen),
      ),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFE8E3D9)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: item.iconBg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(item.icon,
                  color: const Color(0xFF1A5C2A), size: 22),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  style: GoogleFonts.dmSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF1A3A1F),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  item.subtitle,
                  style: GoogleFonts.dmSans(
                    fontSize: 11,
                    color: const Color(0xFF8A9C7E),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── Grid item model ──────────────────────────────
class _GridItem {
  final String title;
  final IconData icon;
  final String subtitle;
  final Color iconBg;
  final Widget screen;

  const _GridItem(
      this.title, this.icon, this.subtitle, this.iconBg, this.screen);
}